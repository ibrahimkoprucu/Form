﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FourCalculation.UI
{
    public partial class frmMainForm : Form
    {
        public frmMainForm()
        {
            InitializeComponent();
        }

        ToplamaForm frmToplama;
        CıkarmaForm frmCıkarma;
        CarpmaForm frmCarpma;
        BolmeForm frmBolme;
        private void btnToplama_Click(object sender, EventArgs e)
        {

            if (frmToplama==null)
            {
                frmToplama = new ToplamaForm();
                frmToplama.Show();

            }
            else
            {
                
                if (frmToplama.WindowState== FormWindowState.Minimized)
                {
                    btnToplama.Text = "Asagıdan cagır";
                    frmToplama.WindowState = FormWindowState.Normal;

                }


                
                frmToplama.BringToFront();
               
                
            }
            frmToplama.FormClosed += delegate { frmToplama = null; };
           

        }

        private void btnCıkarma_Click(object sender, EventArgs e)
        {
            FormManager f = new FormManager();
            f.GetInstance( frmCıkarma);
        }

        private void btnCarpma_Click(object sender, EventArgs e)
        {
            FormManager f = new FormManager();
            f.GetInstance(frmCarpma);
        }

        private void btnBolme_Click(object sender, EventArgs e)
        {
            FormManager f = new FormManager();
            f.GetInstance(frmBolme);
        }
    }
}
