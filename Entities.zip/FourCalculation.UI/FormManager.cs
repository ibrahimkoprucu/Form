﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FourCalculation.UI
{
   public class FormManager
    {
      
        public void GetInstance( ToplamaForm frm1)
        {                                   
            if (frm1 == null)
            {
                frm1 = new ToplamaForm();
                //frm1.FormClosed += delegate { frm1 = null; };
                frm1.Show();
            }
            else
            {
                frm1.WindowState = FormWindowState.Normal;
                frm1.Focus();
            }

            

        }
        
       public void GetInstance( CıkarmaForm frm2)
        {                                   
            if (frm2 == null)
            {
                frm2 = new CıkarmaForm();
                frm2.FormClosed += delegate { frm2 = null; };
                frm2.Show();
            }
            else
            {
                frm2.WindowState = FormWindowState.Normal;
                frm2.Focus();
            }

            

        }
        
         public void GetInstance(CarpmaForm frm3)
        {                                   
            if (frm3 == null)
            {
                frm3 = new CarpmaForm();
                frm3.FormClosed += delegate { frm3 = null; };
                frm3.Show();
            }
            else
            {
                frm3.WindowState = FormWindowState.Normal;
                frm3.Focus();
            }

            

        }
        
         public void GetInstance(BolmeForm frm4)
        {                                   
            if (frm4 == null)
            {
                frm4 = new BolmeForm();
                frm4.FormClosed += delegate { frm4 = null; };
                frm4.Show();
            }
            else
            {
                frm4.WindowState = FormWindowState.Normal;
                frm4.Focus();
            }

            

        }
        



    }
}
